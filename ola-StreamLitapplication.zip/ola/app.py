import streamlit as st
import streamlit.components.v1 as components
import mysql.connector
import pandas as pd

# ---------- Page Config ----------
st.set_page_config(
    page_title="Ola Ride Insights",
    page_icon="📊",
    layout="wide"
)

# ---------- Custom Styling ----------
st.markdown("""
<style>
    .main {
        background-color: #f6f7fb;
    }
    .dashboard-title {
        font-size: 34px;
        font-weight: 800;
        text-align: center;
        color: #1f2937;
        margin-bottom: 4px;
    }
    .dashboard-subtitle {
        font-size: 16px;
        text-align: center;
        color: #6b7280;
        margin-bottom: 30px;
    }
    .dashboard-card {
        background-color: white;
        padding: 24px;
        border-radius: 18px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }
    iframe {
        border-radius: 14px;
    }
</style>
""", unsafe_allow_html=True)

# ---------- Database Connection ----------
def create_connection():
    connection = mysql.connector.connect(
        host="127.0.0.1",      
        user="root",            
        password="Hasini@6124",    
        database="ola_database"       
    )
    return connection

@st.cache_data
def get_data(query):
    conn = create_connection()
    df = pd.read_sql(query, conn)
    conn.close()
    return df

# ---------- Header ----------
st.markdown("<div class='dashboard-title'>📊 Ola Ride Insights</div>", unsafe_allow_html=True)
st.markdown(
    "<div class='dashboard-subtitle'>Real-time Power BI Analytics Embedded in Streamlit</div>",
    unsafe_allow_html=True
)

# ---------- Sidebar ----------
with st.sidebar:
    st.header("⚙ Dashboard Panel")
    st.markdown("Use Power BI filters inside the report.")
    st.divider()
    
    # SQL Query Section
    st.markdown("**SQL Query Viewer**")
    user_query = st.text_area(
        "Enter SQL query to preview data:",
        "SELECT * FROM rides LIMIT 10;"
    )
    if st.button("Run SQL Query"):
        try:
            df = get_data(user_query)
            st.write("Query Result:")
            st.dataframe(df)
        except Exception as e:
            st.error(f"Error executing query: {e}")
    
    st.markdown("""
    **Upcoming Enhancements**
    - Date & City Filters  
    - SQL-Driven Controls  
    - Export Reports  
    """)

# ---------- Power BI Embed ----------
power_bi_url = (
    "https://app.powerbi.com/reportEmbed?reportId=ce6603e3-ac2f-4606-b157-f913303b281d&autoAuth=true&ctid=49f885b5-40f1-48a7-847f-c1f870f6d802"
)

st.markdown("<div class='dashboard-card'>", unsafe_allow_html=True)

components.iframe(
    power_bi_url,
    height=720,
    scrolling=True
)

st.markdown("</div>", unsafe_allow_html=True)

# ---------- Footer ----------
st.markdown(
    "<p style='text-align:center; color:#9ca3af; margin-top:25px;'>"
    "© 2026 Ola Analytics Platform | Streamlit × Power BI"
    "</p>",
    unsafe_allow_html=True
)
